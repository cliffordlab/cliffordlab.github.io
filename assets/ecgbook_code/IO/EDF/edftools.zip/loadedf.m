function [s, e]=loadedf(edf, chans)
% [s e] =loadedf(edf, chans)
% Returns all of the data in the specified edf file from the specified channels.
% chans = 0 returns all data. e contains the header info, s the signal.
% e.g. [s e] =loadedf('my_file.edf', 1);

e = gdfopen(edf);
s = gdfread(e,chans,'A',e.NRec,0);
gdfclose(e);
