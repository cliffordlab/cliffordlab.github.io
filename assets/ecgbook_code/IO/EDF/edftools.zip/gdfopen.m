function [EDF,H1,h2]=gdfopen(arg1,arg2,arg3,arg4,arg5)
% Defines an EDF-struct
%
% EDF.ErrNo~=0  indicates that an error occured.
% For compatibility to former versions, 
%    EDF.FILE.FID = -1 indicates that file has not been opened.
%
% [EDF]=gdfopen(EDFin,'w')
% Opens an EDF/GDF File for writing
% EDFin has to be a struct as defined in EDFOPEN(filename,'r')
%
% if EDF.VERSION(1:8)=='GDF.....' the GDF format definition is used. 
% else the EDF-format is used
% The "specification of GDF" is available on request from <a.schloegl@ieee.org>
%
% EDF is a struct that describes the EDF/GDF-Header information within Matlab
%
% The Channel type is defined in EDF.GDFTYP with the following Code
%          TYPE       bytes     Code
%          char		1       0
%          int8		1       1
%          uint8	1	2
%          int16	2	3
%          uint16	2	4
%          int32	4	5
%          uint32	4	6
%          int64	8	7
%          float32	4	16
%          float64	8	17
% For EDF files is always EDF.GDFTYP(1:EDF.NS)=3;

%
%	For use under Octave define the function UPPER.M
% function s=upper(s); s=toupper(s); end;
%

% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; either version 2
% of the  License, or (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

INFO='(C) 1997-1999 by Alois Schloegl, 22. Jun 1999 #0.47';
%	a.schloegl@ieee.org
%	Version 0.47
%
%  1x Apr 1999 call to gdfcheck removed
%  26 Apr 1999 Calculation of Cal etc. included again
%  27 Apr 1999 made "reading the recording time" EDF.T0 more robust
%              EDF.ErrNo included defined: 0(no),1,2,4,8,16,32 (file open error)
%  12 May 1999 EDF.AS.startrec and EDF.AS.numrec included
%  22 Jun 1999 EDF.ErrNo 64 included. Now defined: 0(no),1,2,4,8,16,32,64 (file open error)
%              Y2K problem modified: yy<=50 gives 20yy; yy>50 gives 19yy
%

if nargin<2 arg2='r';end;

if exist('OCTAVE_VERSION')
        EDF.AS.Method='edfopen';
else 
        EDF.AS.Method=mfilename;
end;
EDF.AS.Method=[EDF.AS.Method '-' arg2];
EDF.AS.Date=fix(clock);
EDF.AS.Info=INFO;
EDF.AS.Ver = 0.47;

if isstruct(arg1) 
        EDF=arg1; 
        FILENAME=EDF.FileName;
else
        FILENAME=arg1;
end;

H1idx=[8 80 80 8 8 8 44 8 8 4];
H2idx=[16 80 8 8 8 8 8 80 8 32];

%%%%% Define Valid Data types %%%%%%
%GDFTYPES=[0 1 2 3 4 5 6 7 16 17 255+(1:64) 511+(1:64)];
GDFTYPES=[0 1 2 3 4 5 6 7 16 17 255+[1 12 22 24] 511+[1 12 22 24]];

%%%%% Define Size for each data type %%%%%
GDFTYP_BYTE=zeros(1,512+64);
GDFTYP_BYTE(256+(1:64))=(1:64)/8;
GDFTYP_BYTE(512+(1:64))=(1:64)/8;
GDFTYP_BYTE(1:18)=[1 1 1 2 2 4 4 8 8 4 8 0 0 0 0 0 4 8]';

%EDF.GDFTYP.TEXT={'char','int8','uint8','int16','uint16','int32','uint32','int64','uint64','float32','float64'};
%GDFTYP_BYTE=[1 1 1 2 2 4 4 8 8 4 8 0 0 0 0 0 4 8]';
%GDFTYPES=[0 1 2 3 4 5 6 7 16 17];

EDF.ERROR=[];
EDF.ErrNo = 0;

%%%%%%% ============= READ ===========%%%%%%%%%%%%
if arg2=='r'

[EDF.FILE.FID,MESSAGE]=fopen(FILENAME,'r','ieee-le');          
%EDF.FILE.FID=fid;

if EDF.FILE.FID<0 
        %fprintf(2,'Error GDFOPEN: %s %s\n',MESSAGE,FILENAME);  
        H1=MESSAGE; H2=FILENAME;
	EDF.ERROR=sprintf('Invalid Filename %s', FILENAME);
        EDF.ErrNo = EDF.ErrNo + 32;
	return;
end;
EDF.FILE.OPEN = 1;
EDF.FileName = FILENAME;

PPos=min([max(find(FILENAME=='.')) length(FILENAME)+1]);
SPos=max([0 find(FILENAME==filesep)]);
EDF.FILE.Ext = FILENAME(PPos+1:length(FILENAME));
EDF.FILE.Name = FILENAME(SPos+1:PPos-1);
if SPos==0
	EDF.FILE.Path = pwd;
else
	EDF.FILE.Path = FILENAME(1:SPos-1);
end;
EDF.FileName = [EDF.FILE.Path filesep EDF.FILE.Name '.' EDF.FILE.Ext];

%%% Read Fixed Header %%%
[tmp,count]=fread(EDF.FILE.FID,184,'uchar');     %
if count<184
        EDF.ERROR = sprintf('Error GDFOPEN-R: Fixed Header not read correctly');
        EDF.ErrNo = EDF.ErrNo + 64;
        return;
end;
H1=setstr(tmp');     %

EDF.VERSION=H1(1:8);                     % 8 Byte  Versionsnummer 
if ~(strcmp(EDF.VERSION,'0       ') | strcmp(EDF.VERSION(1:3),'GDF'))
        fprintf(2,'Warning GDFOPEN: Invalid or corrupted EDF/GDF file or invalid Version number ''%s''\n',EDF.VERSION); 
        EDF.ERROR=[EDF.ERROR 'WARNING W01: invalid Version number "' EDF.VERSION '"'];
        EDF.ErrNo = EDF.ErrNo + 1;
	if ~strcmp(EDF.VERSION(1:3),'   '); % if not a scoring file, 
	    return; 
	end;
end;
EDF.PID = deblank(H1(9:88));                  % 80 Byte local patient identification
EDF.RID = deblank(H1(89:168));                % 80 Byte local recording identification
%EDF.H.StartDate = H1(169:176);         % 8 Byte		
%EDF.H.StartTime = H1(177:184);         % 8 Byte		
%EDF.HeadLen = str2num(H1(185:192));           % 8 Byte  Length of Header
        % reserved = H1(193:236);	              % 44 Byte		

GDF=strcmp(EDF.VERSION(1:3),'GDF');

if GDF
        %EDF.T0=[str2num(H1(168+[1:4])) str2num(H1(168+[5 6])) str2num(H1(168+[7 8])) str2num(H1(168+[9 10])) str2num(H1(168+[11 12])) str2num(H1(168+[13:16]))/100 ];
        if 1, % if strcmp(EDF.VERSION(4:8),' 0.12'); % in future versions the date format might change. 
      		EDF.T0(1) = str2num( H1(168 + [ 1:4]));
		EDF.T0(2) = str2num( H1(168 + [ 5 6]));
        	EDF.T0(3) = str2num( H1(168 + [ 7 8]));
        	EDF.T0(4) = str2num( H1(168 + [ 9 10]));
        	EDF.T0(5) = str2num( H1(168 + [11 12]));
        	EDF.T0(6) = str2num( H1(168 + [13:16]))/100;
     	end; 
     
	if str2num(EDF.VERSION(4:8))<0.12
                tmp = setstr(fread(EDF.FILE.FID,8,'uchar')');    % 8 Byte  Length of Header
                EDF.HeadLen = str2num(tmp);    % 8 Byte  Length of Header
        else
                EDF.HeadLen = fread(EDF.FILE.FID,1,'int64');    % 8 Byte  Length of Header
        end;
        tmp = fread(EDF.FILE.FID,8+8+8+20,'uchar');     % 44 Byte reserved
        
        EDF.NRec   = fread(EDF.FILE.FID,1,'int64');     % 8 Byte  # of data records
        if strcmp(EDF.VERSION(4:8),' 0.10')
                EDF.Dur =  fread(EDF.FILE.FID,1,'float64');    % 8 Byte  # duration of data record in sec
        else
                tmp =  fread(EDF.FILE.FID,2,'uint32');    % 8 Byte  # duration of data record in sec
                EDF.Dur =  tmp(1)./tmp(2);
        end;
        EDF.NS =   fread(EDF.FILE.FID,1,'uint32');     % 4 Byte  # of signals
else 
        %EDF.T0=[str2num(H1(168+[7 8])) str2num(H1(168+[4 5])) str2num(H1(168+[1 2])) str2num(H1(168+[9 10])) str2num(H1(168+[12 13])) str2num(H1(168+[15 16])) ];
        EDF.T0 = zeros(1,6);
        ErrT0=0;
        tmp = str2num( H1(168 + [ 7  8]));
        if ~isempty(tmp), EDF.T0(1) = tmp; else ErrT0=1; end;
        tmp = str2num( H1(168 + [ 4  5]));
        if ~isempty(tmp), EDF.T0(2) = tmp; else ErrT0=1; end;
        tmp = str2num( H1(168 + [ 1  2]));
        if ~isempty(tmp), EDF.T0(3) = tmp; else ErrT0=1; end;
        tmp = str2num( H1(168 + [ 9 10]));
        if ~isempty(tmp), EDF.T0(4) = tmp; else ErrT0=1; end;
        tmp = str2num( H1(168 + [12 13]));
        if ~isempty(tmp), EDF.T0(5) = tmp; else ErrT0=1; end;
        tmp = str2num( H1(168 + [15 16]));
        if ~isempty(tmp), EDF.T0(6) = tmp; else ErrT0=1; end;
        
        if ErrT0
                EDF.ERROR = [EDF.ERROR 'E02: invalid recording date\n'];   
                EDF.ErrNo = EDF.ErrNo + 2;
        else
                % Y2K compatibility until year 2050
                if EDF.T0(1) < 51    % for biomedical data recorded in the 1950's and converted to EDF
                        EDF.T0(1)=2000+EDF.T0(1);
                elseif EDF.T0(1) < 100
                        EDF.T0(1)=1900+EDF.T0(1);
                %else % already corrected, do not change
                end;
        end;     
        
        H1(185:256)=setstr(fread(EDF.FILE.FID,256-184,'uchar')');     %
        EDF.HeadLen = str2num(H1(185:192));           % 8 Byte  Length of Header
        EDF.NRec    = str2num(H1(237:244));     % 8 Byte  # of data records
        EDF.Dur     = str2num(H1(245:252));     % 8 Byte  # duration of data record in sec
        EDF.NS      = str2num(H1(253:256));     % 4 Byte  # of signals
	EDF.AS.H1   = H1;	                     % for debugging the EDF Header
end;

if EDF.T0(1)>EDF.AS.Date(1)
        EDF.ERROR=[EDF.ERROR 'E03: Incorrect date information\n'];
        EDF.ErrNo = EDF.ErrNo + 4;
end;

%%% Read variable Header %%%
if ~GDF
        idx1=cumsum([0 H2idx]);
        idx2=EDF.NS*idx1;

        h2=zeros(EDF.NS,256);
        [H2,count]=fread(EDF.FILE.FID,EDF.NS*256,'uchar');
        if count < EDF.NS*256 
                EDF.ERROR=sprintf('unable to read variable Header of %s \n', FILENAME);
                EDF.ErrNo = EDF.ErrNo + 8;
                fprintf(2,'Warning GDFOPEN: unable to read header\n'); 
                return; 
        end;
                
        tmp=(find(H2==0)); 
        if ~isempty(tmp) %%%%% not EDF because filled out with ASCII(0) - should be spaces
                H2(tmp)=32; 
        end;
        
        for k=1:length(H2idx);
                %disp([k size(H2) idx2(k) idx2(k+1) H2idx(k)]);
                h2(:,idx1(k)+1:idx1(k+1))=reshape(H2(idx2(k)+1:idx2(k+1)),H2idx(k),EDF.NS)';
        end;
        h2=setstr(h2);

        EDF.Label      =         h2(:,idx1(1)+1:idx1(2));
        EDF.Transducer =         h2(:,idx1(2)+1:idx1(3));
        EDF.PhysDim    =         h2(:,idx1(3)+1:idx1(4));
        EDF.PhysMin    = str2num(h2(:,idx1(4)+1:idx1(5)));
        EDF.PhysMax    = str2num(h2(:,idx1(5)+1:idx1(6)));
        EDF.DigMin     = str2num(h2(:,idx1(6)+1:idx1(7)));
        EDF.DigMax     = str2num(h2(:,idx1(7)+1:idx1(8)));
        EDF.PreFilt    =         h2(:,idx1(8)+1:idx1(9));
        EDF.SPR        = str2num(h2(:,idx1(9)+1:idx1(10)));
        %EDF.reserved  =       h2(:,idx1(10)+1:idx1(11));
        EDF.GDFTYP     = 3*ones(1,EDF.NS);	%	datatype
else
        fseek(EDF.FILE.FID,256,'bof');
        EDF.Label      =  setstr(fread(EDF.FILE.FID,[16,EDF.NS],'uchar')');		
        EDF.Transducer =  setstr(fread(EDF.FILE.FID,[80,EDF.NS],'uchar')');	
        EDF.PhysDim    =  setstr(fread(EDF.FILE.FID,[8,EDF.NS],'uchar')');
%       EDF.AS.GDF.TEXT = EDF.GDFTYP.TEXT;
        EDF.PhysMin    =         fread(EDF.FILE.FID,[EDF.NS,1],'float64');	
        EDF.PhysMax    =         fread(EDF.FILE.FID,[EDF.NS,1],'float64');	
        EDF.DigMin     =         fread(EDF.FILE.FID,[EDF.NS,1],'int64');	
        EDF.DigMax     =         fread(EDF.FILE.FID,[EDF.NS,1],'int64');	
        
        EDF.PreFilt    =  setstr(fread(EDF.FILE.FID,[80,EDF.NS],'uchar')');	%	
        EDF.SPR        =         fread(EDF.FILE.FID,[1,EDF.NS],'uint32')';	%	samples per data record
        EDF.GDFTYP     =         fread(EDF.FILE.FID,[1,EDF.NS],'uint32');	%	datatype
        %                        fread(EDF.FILE.FID,[32,EDF.NS],'uchar')';	%	datatype
end;


%		EDF=gdfcheck(EDF,1);
EDF.Cal = (EDF.PhysMax-EDF.PhysMin)./(EDF.DigMax-EDF.DigMin);
EDF.Off = EDF.PhysMin - EDF.Cal .* EDF.DigMin;
EDF.Calib=[EDF.Off';(diag(EDF.Cal))];
EDF.SampleRate = EDF.SPR / EDF.Dur;

EDF.AS.spb = sum(EDF.SPR);	% Samples per Block
EDF.AS.bi = [0;cumsum(EDF.SPR)]; 
EDF.AS.BPR  = ceil(EDF.SPR.*GDFTYP_BYTE(EDF.GDFTYP+1)'); 
%EDF.AS.GDFbi= [0;cumsum(EDF.AS.BPR)];
EDF.AS.GDFbi = [0;cumsum(ceil(EDF.SPR.*GDFTYP_BYTE(EDF.GDFTYP+1)'))]; 
EDF.AS.bpb = sum(ceil(EDF.SPR.*GDFTYP_BYTE(EDF.GDFTYP+1)'));	% Bytes per Block
EDF.AS.startrec = 0;
EDF.AS.numrec = 0;

%EDF.FILE.POS = ftell(EDF.FILE.FID);
status = fseek(EDF.FILE.FID, 0, 'eof');
endpos = ftell(EDF.FILE.FID);
fseek(EDF.FILE.FID, EDF.HeadLen, 'bof');

if EDF.NRec == -1   % unknown record size, determine correct NRec
        EDF.NRec = floor((endpos - EDF.HeadLen) / EDF.AS.bpb);
elseif  EDF.NRec ~= ((endpos - EDF.HeadLen) / EDF.AS.bpb);
        fprintf(2,'Warning GDFOPEN: Incorrect HeaderInformation does not fit to filesize\n');
        EDF.ErrNo = EDF.ErrNo + 16;
end; 


%%%%%%% ============= WRITE ===========%%%%%%%%%%%%        

elseif arg2=='w'
%        fprintf(2,'error EDFOPEN: write mode not possible.\n'); 
        H1=[]; H2=[];
%        return;
        
if ~isstruct(arg1) 
        fprintf(2,'error EDFOPEN: arg1 must be defined as EDF-struct\n'); return;
else
        FILENAME=EDF.FileName;
        [fid,MESSAGE]=fopen(FILENAME,'w','ieee-le');          
        EDF.FILE.FID = fid;
        if fid<0 
                %fprintf(2,'Error EDFOPEN: %s\n',MESSAGE);  
                H1=MESSAGE;H2=[];
	        EDF.ErrNo = EDF.ErrNo + 32;
                return;
        end;
end;
EDF.FILE.OPEN = 2;

%%%% generate optional parameters

PPos=min([max(find(FILENAME=='.')) length(FILENAME)+1]);
SPos=max([0 find(FILENAME==filesep)]);
EDF.FILE.Ext = FILENAME(PPos+1:length(FILENAME));
EDF.FILE.Name = FILENAME(SPos+1:PPos-1);
if SPos==0
	EDF.FILE.Path = pwd;
else
	EDF.FILE.Path = FILENAME(1:SPos-1);
end;
EDF.FileName = [EDF.FILE.Path filesep EDF.FILE.Name '.' EDF.FILE.Ext];

EDF.NRec=-1;
EDF=gdfcheck(EDF,1);
EDF.AS.startrec=0;
EDF.AS.numrec=0;

GDF=strcmp(EDF.VERSION(1:3),'GDF');
if ~GDF
        EDF.VERSION = '0       ';
        fprintf(2,'\nWARNING: It is not recommended to use this funtion because You try to store Matlab data (floating point numbers) within integer16 number.\n Overflow and round off errors can damage your data.\n We recommend to set arg.VERSION=''GDF 0.12'' \n');  
else
        EDF.VERSION = 'GDF 0.12';
end;

%%%%%% generate Header 1, first 256 bytes 

EDF.HeadLen=(EDF.NS+1)*256;
H1=setstr(32*ones(1,256));
H1(1:8)=EDF.VERSION; %sprintf('%08i',EDF.VERSION);     % 8 Byte  Versionsnummer 
H1(8+(1:length(EDF.PID)))=EDF.PID;       
H1(88+(1:length(EDF.RID)))=EDF.RID;
%H1(185:192)=sprintf('%-8i',EDF.HeadLen);

if GDF
        H1(168+(1:16))=sprintf('%04i%02i%02i%02i%02i%02i%02i',floor(EDF.T0),rem(EDF.T0(6),1));
        fwrite(fid,H1(1:184),'uchar');
        fwrite(fid,EDF.HeadLen,'int64');
        fwrite(fid,ones(8,1)*32,'byte'); % EP_ID=ones(8,1)*32;
        fwrite(fid,ones(8,1)*32,'byte'); % Lab_ID=ones(8,1)*32;
        fwrite(fid,ones(8,1)*32,'byte'); % T_ID=ones(8,1)*32;
        fwrite(fid,ones(20,1)*32,'byte'); % T_ID=ones(8,1)*32;
        fwrite(fid,EDF.NRec,'int64');
        %fwrite(fid,EDF.Dur,'float64');
        [n,d]=rat(EDF.Dur); fwrite(fid,[n d], 'uint32');
        fwrite(fid,EDF.NS,'uint32');
else
        H1(168+(1:16))=sprintf('%-2i.%-2i.%-2i%-2i:%-2i:%-2i',rem(EDF.T0([3 2 1 4 5 6]),100));
        H1(185:192)=sprintf('%-8i',EDF.HeadLen);
        H1(237:244)=sprintf('%-8i',EDF.NRec);
        H1(245:252)=sprintf('%-8i',EDF.Dur);
        H1(253:256)=sprintf('%-4i',EDF.NS);
        H1(find(H1==0))=32;
        fwrite(fid,H1,'uchar');
end;        

%%%%%% generate Header 2,  NS*256 bytes 
if ~GDF; 
        EDF.sPhysMin=reshape(sprintf('%-8.1f',EDF.PhysMin)',8,EDF.NS)';
        EDF.sPhysMax=reshape(sprintf('%-8.1f',EDF.PhysMax)',8,EDF.NS)';
        
        idx1=cumsum([0 H2idx]);
        idx2=EDF.NS*idx1;
        h2=setstr(32*ones(EDF.NS,256));
        h2(:,idx1(1)+1:idx1(2))=EDF.Label;
        h2(:,idx1(2)+1:idx1(3))=EDF.Transducer;
        h2(:,idx1(3)+1:idx1(4))=EDF.PhysDim;
        h2(:,idx1(4)+1:idx1(5))=EDF.sPhysMin;
        h2(:,idx1(5)+1:idx1(6))=EDF.sPhysMax;
        h2(:,idx1(6)+1:idx1(7))=reshape(sprintf('%-8i',EDF.DigMin)',8,EDF.NS)';
        h2(:,idx1(7)+1:idx1(8))=reshape(sprintf('%-8i',EDF.DigMax)',8,EDF.NS)';
        h2(:,idx1(8)+1:idx1(9))=EDF.PreFilt;
        h2(:,idx1(9)+1:idx1(10))=reshape(sprintf('%-8i',EDF.SPR)',8,EDF.NS)';
        h2(h2==0)=32;
        for k=1:length(H2idx);
                fwrite(fid,h2(:,idx1(k)+1:idx1(k+1))','uchar');
        end;
else
        fwrite(fid, EDF.Label','16*uchar');
        fwrite(fid, EDF.Transducer','80*uchar');
        fwrite(fid, EDF.PhysDim','8*uchar');
        fwrite(fid, EDF.PhysMin,'float64');
        fwrite(fid, EDF.PhysMax,'float64');
        fwrite(fid, EDF.DigMin,'int64');
        fwrite(fid, EDF.DigMax,'int64');
        fwrite(fid, EDF.PreFilt','80*uchar');
        fwrite(fid, EDF.SPR,'uint32');
        fwrite(fid, EDF.GDFTYP,'uint32');
        fprintf(fid,'%c',32*ones(32,EDF.NS));
end;

tmp = ftell(EDF.FILE.FID);
if tmp ~= (256 * (EDF.NS+1)) 
        fprintf(1,'edfopen in write mode: incorrect header length %i bytes\n',tmp);
%else   fprintf(1,'edfopen in write mode: header info stored correctly\n');
end;        
end;        

%%%%%%% ENDE %%%%%%%%%

