function s=loadrawedf(edf, chans)
% s=loadrawedf(edf, chans)
% Returns all of the data in the specified edf file from the specified channels.
% chans = 0 returns all data.  Returns raw data.

e = gdfopen(edf);
s = gdfread(e,chans,0,e.NRec,0);
gdfclose(e);
