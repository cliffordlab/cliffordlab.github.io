function [s, e]=loadedf_corrupt(edf, chans)
% s=loadedf_corrupt(edf, chans)
% Returns all of the data in the specified edf file from the 
% specified channels, except the last (corrupted?) line.
% chans = 0 returns all data.

e = gdfopen(edf);
s = gdfread_corrupt(e,chans,'A',e.NRec,0);
gdfclose(e);
