function [POS]=gdftell(arg1)
% Position=gdftell(EDF_Struct)
%
% returns the location of the EDF_file position indicator in the specified file.  
% Position is indicated in Blocks from the beginning of the file.  If -1 is returned, 
% it indicates that the query was unsuccessful; 
% EDF_Struct is a struct obtained by edfopen.
% 
%    See also GDFOPEN, GDFSEEK, FTELL

%	Version 0.46
%	12 May 1999
%	Copyright (c) 1997-1999 by Alois Schloegl
%	a.schloegl@ieee.org	

% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; either version 2
% of the  License, or (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

%  12 May 1999 EDF.AS.startrec and EDF.AS.numrec included

EDF=arg1;

POS = ftell(EDF.FILE.FID);
if POS<0 return; end;

POS = (POS-EDF.HeadLen)/EDF.AS.bpb;
EDF.AS.startrec = POS;
%EDF.AS.numrec=0;

