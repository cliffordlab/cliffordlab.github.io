function [ResEDF, ResUserData] = plugtemplate(EDF, UserData, Opt)
% template for a plugin function
% a plugin *must* set the ResEDF values for:
%   Head.NS, Head.NRec, Head.PhysMin, Head.PhysMax, Labels

% Changes:
% 09/18/98 : data format changed

if nargin < 3
  Opt = '';
end

switch Opt
  case 'Reset'
    % Check whether EDF File has changed, update UserData, ...
    [ResEDF, ResUserData] = LocalReset(EDF, UserData);
  case 'Menu'
    % set UserData if necessary
    [ResEDF, ResUserData] = LocalConfigure(EDF, UserData);
  otherwise
    % Update ResEDF
    [ResEDF, ResUserData] = LocalUpdate(EDF, UserData);
end
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ResEDF, ResUserData] = LocalConfigure(EDF, UserData)
[ResEDF, ResUserData] = LocalUpdate(EDF, UserData);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ResEDF, ResUserData] = LocalReset(EDF, UserData)
[ResEDF, ResUserData] = LocalUpdate(EDF, UserData);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ResEDF, ResUserData] = LocalUpdate(EDF, UserData)
% This function returns the first channel of the first EDF file
ResUserData = UserData;
ResEDF.Record{1} = EDF(1).Record{1};
ResEDF.Head = EDF(1).Head;
ResEDF.Head.NS = 1;
ResEDF.Head.Label = 'Plugin template';
ResEDF.Head.NRec = EDF(1).Head.NRec(1);





